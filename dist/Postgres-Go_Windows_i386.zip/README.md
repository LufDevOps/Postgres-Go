# Book-Keeping-API

## Go dependecies
`go get github.com/jinzhu/gorm github.com/jinzhu/gorm/dialects/postgres github.com/gorilla/mux`


## Use
Replace the `.env` file with the credientials to your database, then run `source .env` in your terminal and start the program `go run main.go`
